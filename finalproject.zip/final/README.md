Feedback

Part 1 I went over and beyond the scope of the class and experimented with Python classes in my code.  I did this because I wanted to create separate instances of the game and guesses in order to maintain separation of data in memory for the script running simultaneously on one machine.

I was disappointed to find that the networking notes were of little use, and the code itself did not work for the server side.  I found online resources that were more helpful.  Otherwise an interesting part of the project.

For part 2, only one temporary file is created.  This is the initial download of the website, and is parsed later and then deleted.  This can be avoided by downloading the website twice and parsing it twice.  In addition, the website was down when this code was being tested.  The website found on piazza was used, with the original left in a commented-out block.
